package br.com.senai.model;
import java.util.ArrayList;

public class Biblioteca{

    private String livro;
    private ArrayList<Livro> livros;


    public Biblioteca(String nome) {
        this.livro = nome;
    }
    public ArrayList<Livro> getLivros() {
        return livros;
    }
    public void setNome(ArrayList<Livro> livros) {
        this.livros = livros;
    }
    public String getNome() {
        return livro;
    }
    public void setNome(String nome) {
        this.livro = nome;
    }
    public void setLivro(ArrayList<Livro> livro){
    }
    public void setLivros() {
        this.livros = livros;
    }

}