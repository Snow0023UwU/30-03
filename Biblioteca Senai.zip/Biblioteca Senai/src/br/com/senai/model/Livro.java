package br.com.senai.model;
import br.com.senai.Main;

public class Livro {
    private final String livro;
    private String livros;
    public String livro1;

    public Livro(String nome) {
        this.livro = nome;
    }

    public String getNome() {
        return livro;
    }

    @Override
    public String toString() {
        return "Livro:" + this.livros;
    }
}
