package br.com.senai;

import br.com.senai.model.Biblioteca;
import br.com.senai.model.Livro;
import br.com.senai.model.Livro;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class Main {

    // codigo baseado no do dia 29/03 ( Tema: Futebol )

    public static void main (String []args){
        Biblioteca biblioteca1  = new Biblioteca ("Biblioteca Sesi Senai Florianópolis");
        ArrayList<Livro> listFla = new ArrayList<Livro>();
        listFla.add(new Livro("Harry Potter"));
        listFla.add(new Livro("Senhor dos Aneis"));
        listFla.add(new Livro("Reliquias da Morte"));
        listFla.add(new Livro("Pequeno Principe"));
        listFla.add(new Livro("A Menina Que Roubava Livros"));
        biblioteca1.setLivros();

        Biblioteca biblioteca2 = new Biblioteca("Biblioteca Seso Senai São José");
        ArrayList<Livro> listFla1 = new ArrayList<Livro>();
        listFla1.add(new Livro("Dom Quixote"));
        listFla1.add(new Livro("Cem Anos de Solidão"));
        listFla1.add(new Livro("Em Busca do Tempo Perdido"));
        listFla1.add(new Livro("Sapiens: Uma breve história da humanidade"));
        listFla1.add(new Livro("Pequeno Principe"));
        biblioteca2.setLivros();

        System.out.println();







    }
}
